# Diagrama UML — Sistema de Gerenciamento de Academia

## Arquivos
- `docs/diagramas/casos-de-uso.png`: imagem pronta para visualizar/entregar.
- `docs/diagramas/casos-de-uso.puml`: fonte editável em PlantUML.

## Como adicionar ao GitHub
1. Abra o repositório do grupo.
2. Entre na pasta `docs`. Se ela não existir, crie-a.
3. Dentro dela, crie a pasta `diagramas`.
4. Envie os dois arquivos (`casos-de-uso.png` e `casos-de-uso.puml`).
5. Faça o commit, por exemplo: `Adiciona diagrama UML de casos de uso`.

## Atores e funcionalidades
- **Administrador:** autenticação, gerenciamento de alunos e instrutores, planos, pagamentos e consulta de vencimentos.
- **Instrutor:** autenticação, registro de frequência, consulta de alunos e montagem/acompanhamento de treinos.

A relação `<<include>>` entre “Controlar pagamentos” e “Consultar vencimentos” representa a consulta de vencimentos como parte do acompanhamento dos pagamentos. Ajustem os nomes e permissões se o documento de casos de uso da Pessoa 3 definir regras diferentes.
